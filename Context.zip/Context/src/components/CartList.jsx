import React, { useContext } from 'react'
import { CartContext } from '../context/cart-context'

export default function CartList() {
  const { itemsInCart } = useContext(CartContext)

  return (
    <div>
      <h2>Cart</h2>
      <div className="cart-wrapper">
        {itemsInCart.map((item) => (
          // cart item won't be unique if more than one of an item is added
          <span key={item.id}>{item.symbol}</span>
        ))}
      </div>
    </div>
  )
}
