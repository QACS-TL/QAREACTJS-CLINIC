const Image = () => {
    return ( 
        <div className="image">
            <img src="https://i.pinimg.com/originals/84/b1/06/84b1065e798f61aa80b8670a4b6fbb4d.png"
                width="200px"
            />
        </div>
     );
}
 
export default Image;