import Create from './Create';
import './App.css';

function App() {
  return (
    <div className="App">
        <h2>Add new Records</h2>
        <Create />
    </div>
  );
}

export default App;

